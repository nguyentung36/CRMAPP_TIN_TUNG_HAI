package cybersoft.java12.crmapp.util;

public class ServletConst {

		//Monitors
	public static final String MONITOR = "monitorServlet";
	
		//home
	public static final String HOME = "homeServlet";
	
		//login
	public static final String LOGIN = "loginServlet";
	
		//user
	public static final String USER = "userServlet";
	
		//task 
	public static final String TASK = "taskServlet";
	
		//project
	public static final String PROJECT = "projectServlet";
	
		//role
	public static final String ROLE = "roleServlet";
	
		//status
	public static final String STATUS = "statusServlet";
}
